import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-cajas',
  templateUrl: './page-cajas.component.html',
  styleUrls: ['./page-cajas.component.scss']
})
export class PageCajasComponents implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
