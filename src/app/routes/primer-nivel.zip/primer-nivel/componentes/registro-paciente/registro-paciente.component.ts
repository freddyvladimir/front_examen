import { Component, OnInit, OnDestroy } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import { Subscription } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-registro-paciente',
  templateUrl: './registro-paciente.component.html',
  styleUrls: ['./registro-paciente.component.scss']
})
export class RegistroPacienteComponent implements OnInit {

  formDatosPaciente: FormGroup;

  /////////////////
  fileToUpload: any = null;
	img:any = "assets/images/incognito.png";
  
  constructor(
    private fb: FormBuilder
  ) {
    this.formDatosPaciente = this.fb.group({
      nombre: ['', [Validators.required]],
      apellidoMaterno: ['', [Validators.required]],
      apellidoPaterno: ['', [Validators.required]],
      edad: [''],
      ci: [''],
      duplicado: [''],
      expedido: [''],
      fechaNacimiento: ['', [Validators.required]],
      genero: [''],
      nacionalidad: [''],
      lugarNacimiento: ['', [Validators.required]],
      provincia: [''],
      municipio: [''],
      direccion: ['', [Validators.required]],
      telefono: [''],
      email: ['', [Validators.required, Validators.email]],      
      avatar: [''],
      observaciones: ['']
    });
  }

  ngOnInit(): void {
  }

  getErrorMessage(form: FormGroup) {
    return form.get('email')?.hasError('required')
      ? 'validations.required'
      : form.get('email')?.hasError('email')
      ? 'validations.invalid_email'
      : '';
  }

  

  handleFileInput(event: any) {
    this.fileToUpload = event.target.files[0] ?? null;
    console.log(this.fileToUpload);
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        this.img = reader.result;
    };
    
	}

  guardarDatosPersonales(){
    console.log("formDatosPaciente",this.formDatosPaciente.value);
  }
  
}
